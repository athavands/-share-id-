//
//  ViewController.swift
//  Web Browser Tutorial
//
//  Created by programming-xcode on 2/8/16.
//  Copyright © 2016 programming-xcode. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet var url: UITextField!
    @IBOutlet var webview: UIWebView!
    override func viewDidLoad() {
        super.viewDidLoad()
        webview.loadRequest(NSURLRequest(URL:NSURL(string:"http://google.com/")!))
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func Seqarch(sender: AnyObject) {
        webview.loadRequest(NSURLRequest(URL:NSURL(string:"http://" + url.text! + "/")!))
        if url.text == "" {
            webview.loadRequest(NSURLRequest(URL:NSURL(string:"http://google.com/")!))
        }
    }

}

